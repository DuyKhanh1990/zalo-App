import { Link, useLocation } from "wouter";
import { Calendar, BookOpen, GraduationCap, Receipt } from "lucide-react";
import { cn } from "@/lib/utils";

const TABS = [
  { href: "/schedule", label: "Lịch học", icon: Calendar },
  { href: "/homework", label: "BTVN", icon: BookOpen },
  { href: "/grades", label: "Bảng điểm", icon: GraduationCap },
  { href: "/invoices", label: "Hoá đơn", icon: Receipt },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  return (
    <div className="flex justify-center min-h-screen bg-gray-100 dark:bg-gray-900 w-full overflow-hidden">
      <div className="w-full max-w-[430px] bg-background shadow-xl flex flex-col relative h-[100dvh]">
        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto pb-16">
          {children}
        </main>

        {/* Portal target for fullscreen overlays (sheets, modals) */}
        <div id="sheet-root" className="absolute inset-0 z-[100] pointer-events-none" />

        {/* Bottom Tab Bar */}
        <nav className="absolute bottom-0 left-0 right-0 h-16 bg-background border-t flex justify-around items-center z-50 px-2 safe-area-bottom">
          {TABS.map((tab) => {
            const Icon = tab.icon;
            const isActive = location.startsWith(tab.href);
            return (
              <Link key={tab.href} href={tab.href}>
                <div className={cn(
                  "flex flex-col items-center justify-center w-16 h-full gap-1 cursor-pointer transition-colors duration-200",
                  isActive ? "text-primary" : "text-muted-foreground hover:text-foreground"
                )} data-testid={`tab-${tab.href.replace('/', '')}`}>
                  <Icon className="w-6 h-6" strokeWidth={isActive ? 2.5 : 2} />
                  <span className="text-[10px] font-medium leading-none">{tab.label}</span>
                </div>
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );
}