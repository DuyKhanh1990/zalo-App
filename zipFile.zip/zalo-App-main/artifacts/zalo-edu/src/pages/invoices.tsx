import { useState } from "react";
import { useListInvoices, useGetInvoiceSummary } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Receipt, Calendar, CreditCard } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { formatDate, formatCurrency } from "@/lib/format";

const STATUS_TABS = [
  { id: "all", label: "Tất cả" },
  { id: "unpaid", label: "Chưa thanh toán" },
  { id: "paid", label: "Đã thanh toán" },
];

const getStatusConfig = (status: string) => {
  switch (status) {
    case 'unpaid': return { label: 'Chưa thanh toán', className: 'bg-amber-100 text-amber-800 hover:bg-amber-200 border-transparent' };
    case 'paid': return { label: 'Đã thanh toán', className: 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200 border-transparent' };
    case 'overdue': return { label: 'Quá hạn', className: 'bg-red-100 text-red-800 hover:bg-red-200 border-transparent' };
    default: return { label: status, className: 'bg-slate-100 text-slate-800' };
  }
};

export default function Invoices() {
  const [selectedStatus, setSelectedStatus] = useState("all");
  const { data: invoices, isLoading: invoicesLoading } = useListInvoices();
  const { data: summary, isLoading: summaryLoading } = useGetInvoiceSummary();

  const filteredInvoices = invoices?.filter(item => {
    if (selectedStatus === "all") return true;
    if (selectedStatus === "unpaid" && item.status === "overdue") return true; // Show overdue in unpaid tab
    return item.status === selectedStatus;
  }) || [];

  return (
    <div className="flex flex-col min-h-full bg-slate-50 pb-16">
      <div className="bg-primary pt-12 pb-6 px-4 shadow-sm sticky top-0 z-10 rounded-b-2xl">
        <h1 className="text-xl font-bold text-primary-foreground mb-6">Hoá đơn học phí</h1>
        
        {summaryLoading ? (
          <Skeleton className="h-28 w-full rounded-xl bg-primary-foreground/20" />
        ) : summary ? (
          <Card className="border-none shadow-md bg-white">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-sm text-slate-500 font-medium mb-1">Cần thanh toán</p>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-bold text-primary">{formatCurrency(summary.totalDue)}</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-red-50 rounded-full flex items-center justify-center text-red-500">
                  <CreditCard size={24} />
                </div>
              </div>
              
              <div className="flex gap-4 pt-4 border-t border-slate-100">
                <div className="flex-1">
                  <p className="text-xs text-slate-500 mb-1">Đã thanh toán</p>
                  <p className="font-semibold text-emerald-600 text-sm">{formatCurrency(summary.totalPaid)}</p>
                </div>
                {summary.overdue > 0 && (
                  <div className="flex-1 border-l border-slate-100 pl-4">
                    <p className="text-xs text-slate-500 mb-1">Quá hạn</p>
                    <p className="font-semibold text-red-500 text-sm">{formatCurrency(summary.overdue)}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ) : null}
      </div>

      <div className="flex-1 p-4 -mt-2">
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-3 mb-1">
          {STATUS_TABS.map(tab => (
            <button
              key={tab.id}
              onClick={() => setSelectedStatus(tab.id)}
              className={cn(
                "px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-colors",
                selectedStatus === tab.id
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "bg-white text-slate-600 border border-slate-200 hover:bg-slate-50"
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {invoicesLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <Skeleton key={i} className="h-32 w-full rounded-xl" />
            ))}
          </div>
        ) : filteredInvoices.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-center px-4 mt-4">
            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-3 text-slate-300">
              <Receipt size={32} />
            </div>
            <p className="text-slate-500 font-medium">Không có hoá đơn nào</p>
          </div>
        ) : (
          <div className="space-y-3">
            <AnimatePresence mode="popLayout">
              {filteredInvoices.map((invoice, i) => {
                const statusConfig = getStatusConfig(invoice.status);
                
                return (
                  <motion.div
                    key={invoice.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ delay: i * 0.05 }}
                  >
                    <Card className="border-none shadow-sm overflow-hidden">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start mb-3">
                          <div>
                            <Badge variant="outline" className={cn("mb-2 text-[10px]", statusConfig.className)}>
                              {statusConfig.label}
                            </Badge>
                            <h3 className="font-semibold text-base text-slate-800 leading-tight">{invoice.title}</h3>
                            <p className="text-xs text-slate-500 mt-1">{invoice.semester} • {invoice.category}</p>
                          </div>
                          <div className="text-right pl-2">
                            <span className="font-bold text-primary block">{formatCurrency(invoice.amount)}</span>
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between pt-3 border-t border-slate-100 mt-1">
                          <div className={cn("flex items-center text-xs font-medium", invoice.status === 'overdue' ? "text-red-500" : "text-slate-500")}>
                            <Calendar size={14} className="mr-1.5" />
                            <span>Hạn: {formatDate(invoice.dueDate)}</span>
                          </div>
                          
                          {(invoice.status === 'unpaid' || invoice.status === 'overdue') && (
                            <Button size="sm" className="h-8 text-xs font-medium px-4 rounded-full">
                              Thanh toán
                            </Button>
                          )}
                          {invoice.status === 'paid' && invoice.paidAt && (
                            <span className="text-xs text-emerald-600 font-medium">
                              Đã TT: {formatDate(invoice.paidAt)}
                            </span>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  );
}