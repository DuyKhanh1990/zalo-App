import { useListGrades, useGetGradeSummary } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { GraduationCap, Award, BookX } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

const getGradeColor = (letter: string) => {
  if (['A', 'A+', 'A-'].includes(letter)) return "text-emerald-600 bg-emerald-50";
  if (['B', 'B+', 'B-'].includes(letter)) return "text-blue-600 bg-blue-50";
  if (['C', 'C+', 'C-'].includes(letter)) return "text-amber-600 bg-amber-50";
  if (['D', 'D+', 'D-'].includes(letter)) return "text-orange-600 bg-orange-50";
  return "text-red-600 bg-red-50";
};

export default function Grades() {
  const { data: grades, isLoading: gradesLoading } = useListGrades();
  const { data: summary, isLoading: summaryLoading } = useGetGradeSummary();

  return (
    <div className="flex flex-col min-h-full bg-slate-50 pb-16">
      <div className="bg-primary pt-12 pb-6 px-4 shadow-sm sticky top-0 z-10 rounded-b-2xl">
        <h1 className="text-xl font-bold text-primary-foreground mb-6">Bảng điểm</h1>
        
        {summaryLoading ? (
          <Skeleton className="h-28 w-full rounded-xl bg-primary-foreground/20" />
        ) : summary ? (
          <Card className="border-none shadow-md bg-white">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500 font-medium mb-1">Điểm trung bình (GPA)</p>
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-bold text-primary">{summary.gpa.toFixed(2)}</span>
                    <span className="text-sm font-medium text-emerald-600">Tốt</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center text-primary">
                  <Award size={24} />
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-2 mt-4 pt-4 border-t border-slate-100">
                <div className="text-center">
                  <p className="text-xs text-slate-500 mb-1">Tín chỉ</p>
                  <p className="font-semibold text-slate-800">{summary.totalSubjects}</p>
                </div>
                <div className="text-center border-l border-slate-100">
                  <p className="text-xs text-slate-500 mb-1">Qua môn</p>
                  <p className="font-semibold text-emerald-600">{summary.passed}</p>
                </div>
                <div className="text-center border-l border-slate-100">
                  <p className="text-xs text-slate-500 mb-1">Thi lại</p>
                  <p className="font-semibold text-red-500">{summary.failed}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ) : null}
      </div>

      <div className="flex-1 p-4 -mt-2">
        <h2 className="font-bold text-slate-800 mb-3 px-1">Chi tiết học phần</h2>
        
        {gradesLoading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4].map(i => (
              <Skeleton key={i} className="h-24 w-full rounded-xl" />
            ))}
          </div>
        ) : !grades || grades.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-center px-4 mt-4">
            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-3 text-slate-300">
              <BookX size={32} />
            </div>
            <p className="text-slate-500 font-medium">Chưa có dữ liệu điểm</p>
          </div>
        ) : (
          <div className="space-y-3">
            {grades.map((grade, i) => (
              <motion.div
                key={grade.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <Card className="border-none shadow-sm overflow-hidden">
                  <CardContent className="p-0">
                    <div className="p-3 border-b border-slate-50 bg-slate-50/50 flex justify-between items-center">
                      <div className="flex items-center">
                        <div className="w-8 h-8 rounded bg-primary/10 text-primary flex items-center justify-center mr-3">
                          <GraduationCap size={16} />
                        </div>
                        <h3 className="font-semibold text-sm text-slate-800 line-clamp-1">{grade.subject}</h3>
                      </div>
                      <div className={cn("px-2.5 py-1 rounded-md font-bold text-sm", getGradeColor(grade.letterGrade))}>
                        {grade.letterGrade}
                      </div>
                    </div>
                    
                    <div className="p-3 grid grid-cols-3 gap-2 text-center divide-x divide-slate-100">
                      <div>
                        <p className="text-[10px] text-slate-500 uppercase tracking-wider mb-1">Giữa kỳ</p>
                        <p className="font-medium text-slate-700">{grade.midterm}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-slate-500 uppercase tracking-wider mb-1">Cuối kỳ</p>
                        <p className="font-medium text-slate-700">{grade.final}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-slate-500 uppercase tracking-wider mb-1">Tổng kết</p>
                        <p className="font-bold text-primary">{grade.average}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}