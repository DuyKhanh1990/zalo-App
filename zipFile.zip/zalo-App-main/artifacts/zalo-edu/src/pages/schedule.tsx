import { useState, useMemo } from "react";
import { useListSchedule } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import {
  MapPin, User, ChevronLeft, ChevronRight, Calendar,
  Clock, BookOpen, MessageSquare, Users,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const WEEKDAY_SHORT = ["CN", "T2", "T3", "T4", "T5", "T6", "T7"];
const WEEKDAY_VN_FULL = ["Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy"];

type ScheduleItem = {
  id: number;
  subject: string;
  teacher: string | null;
  room: string;
  dayOfWeek: string;
  startTime: string;
  endTime: string;
  date: string;
  color: string | null;
};

function startOfWeek(date: Date): Date {
  const d = new Date(date);
  d.setDate(d.getDate() - d.getDay());
  d.setHours(0, 0, 0, 0);
  return d;
}

function addDays(date: Date, days: number): Date {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
}

function isSameDay(a: Date, b: Date): boolean {
  return (
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()
  );
}

function formatDateKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function formatMonthYear(d: Date): string {
  return `Tháng ${d.getMonth() + 1}, ${d.getFullYear()}`;
}

function formatFullDate(d: Date): string {
  return `${WEEKDAY_VN_FULL[d.getDay()]}, ${d.getDate()} Tháng ${d.getMonth() + 1} năm ${d.getFullYear()}`;
}

function formatDisplayDate(dateStr: string): string {
  const [y, m, day] = dateStr.split("-");
  return `${day}/${m}/${y}`;
}

// ─── Detail panel ────────────────────────────────────────────────────────────

function DetailPanel({ item, onBack }: { item: ScheduleItem; onBack: () => void }) {
  const accent = item.color || "#7c6fd4";
  const teachers = item.teacher ? item.teacher.split(",").map(t => t.trim()) : [];

  return (
    <motion.div
      key="detail"
      initial={{ x: "100%" }}
      animate={{ x: 0 }}
      exit={{ x: "100%" }}
      transition={{ type: "spring", stiffness: 320, damping: 32 }}
      className="absolute inset-0 z-20 flex flex-col overflow-y-auto"
      style={{ background: "#f5f5fb" }}
    >
      {/* Top bar */}
      <div className="flex items-center gap-3 px-4 pt-10 pb-4 bg-white border-b border-slate-100 sticky top-0 z-10">
        <button
          onClick={onBack}
          className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-slate-100 transition-colors"
        >
          <ChevronLeft size={20} className="text-slate-600" />
        </button>
        <div className="flex-1 flex flex-wrap items-center gap-2">
          <span className="text-xl font-bold text-slate-800">{item.subject}</span>
          <span className="text-xs px-2.5 py-1 rounded-full border border-slate-200 text-slate-500 font-medium">
            Offline
          </span>
          <span className="text-xs px-2.5 py-1 rounded-full border border-slate-200 text-slate-500 font-medium">
            Chưa điểm danh
          </span>
        </div>
      </div>

      {/* Meta */}
      <div className="bg-white px-4 py-3 border-b border-slate-100">
        <div className="flex items-center gap-4 text-sm text-slate-600">
          <div className="flex items-center gap-1.5">
            <Clock size={14} className="text-slate-400" />
            <span style={{ color: accent }} className="font-semibold">
              {item.startTime} – {item.endTime}
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <MapPin size={14} className="text-slate-400" />
            <span>{item.room}</span>
          </div>
        </div>
        <p className="text-xs text-slate-400 mt-1">{formatDisplayDate(item.date)}</p>
        <div className="flex items-center gap-1.5 mt-2">
          <Users size={13} style={{ color: accent }} />
          <span className="text-sm font-medium" style={{ color: accent }}>
            Học viên 1 · HV-01
          </span>
        </div>
      </div>

      <div className="flex flex-col gap-3 p-4">
        {/* Teachers */}
        <div className="bg-white rounded-2xl overflow-hidden shadow-sm">
          <div className="flex items-center justify-between px-4 py-3 border-b border-slate-50">
            <div className="flex items-center gap-2">
              <User size={15} className="text-slate-400" />
              <span className="text-xs font-bold text-slate-500 tracking-wider uppercase">Giáo viên</span>
            </div>
            <span className="text-sm font-semibold text-slate-700">{teachers.length}</span>
          </div>
          {teachers.length > 0 ? (
            <div>
              {teachers.map((t, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between px-4 py-3 border-b border-slate-50 last:border-b-0"
                >
                  <span className="text-sm text-slate-700">{t}</span>
                  <ChevronRight size={16} className="text-slate-300" />
                </div>
              ))}
            </div>
          ) : (
            <p className="px-4 py-3 text-sm text-slate-400">Chưa có thông tin giáo viên.</p>
          )}
        </div>

        {/* Lesson content */}
        <div className="bg-white rounded-2xl overflow-hidden shadow-sm">
          <div className="flex items-center gap-2 px-4 py-3 border-b border-slate-50">
            <BookOpen size={15} className="text-slate-400" />
            <span className="text-xs font-bold text-slate-500 tracking-wider uppercase">Nội dung buổi học</span>
          </div>
          <div className="divide-y divide-slate-50">
            {[
              `Ôn tập lý thuyết: ${item.subject}`,
              "Bài tập thực hành",
            ].map((lesson, i) => (
              <div key={i} className="flex items-center gap-3 px-4 py-3">
                <span
                  className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white flex-shrink-0"
                  style={{ background: accent }}
                >
                  {i + 1}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] text-slate-400 uppercase tracking-wide font-semibold mb-0.5">Bài học</p>
                  <p className="text-sm text-slate-700 leading-snug">{lesson}</p>
                </div>
                <ChevronRight size={16} className="text-slate-300 flex-shrink-0" />
              </div>
            ))}
          </div>
        </div>

        {/* Teacher comments */}
        <div className="bg-white rounded-2xl overflow-hidden shadow-sm">
          <div className="flex items-center gap-2 px-4 py-3 border-b border-slate-50">
            <MessageSquare size={15} className="text-slate-400" />
            <span className="text-xs font-bold text-slate-500 tracking-wider uppercase">Nhận xét từ giáo viên</span>
          </div>
          <p className="px-4 py-4 text-sm text-slate-400 leading-relaxed">
            Chưa có nhận xét từ giáo viên cho buổi học này.
          </p>
        </div>
      </div>
    </motion.div>
  );
}

// ─── Main page ────────────────────────────────────────────────────────────────

export default function Schedule() {
  const today = useMemo(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d;
  }, []);

  const [selectedDate, setSelectedDate] = useState<Date>(today);
  const [weekStart, setWeekStart] = useState<Date>(() => startOfWeek(today));
  const [detail, setDetail] = useState<ScheduleItem | null>(null);

  const { data: schedule, isLoading } = useListSchedule();

  const datesInWeek = useMemo(
    () => Array.from({ length: 7 }, (_, i) => addDays(weekStart, i)),
    [weekStart]
  );

  const daysWithClasses = useMemo(() => {
    if (!schedule) return new Set<string>();
    return new Set(schedule.map(s => s.date));
  }, [schedule]);

  const filteredSchedule = useMemo(() => {
    if (!schedule) return [];
    const key = formatDateKey(selectedDate);
    return schedule
      .filter(s => s.date === key)
      .sort((a, b) => a.startTime.localeCompare(b.startTime));
  }, [schedule, selectedDate]);

  const weekMonth = useMemo(() => formatMonthYear(datesInWeek[3]), [datesInWeek]);

  return (
    <div className="relative flex flex-col min-h-full pb-20 overflow-hidden" style={{ background: "#f0f0f7" }}>
      {/* Purple gradient header */}
      <div
        className="px-4 pt-10 pb-5"
        style={{ background: "linear-gradient(160deg, #c3b8f5 0%, #a89de8 40%, #8f84d8 100%)" }}
      >
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => setWeekStart(prev => addDays(prev, -7))}
            className="w-8 h-8 flex items-center justify-center rounded-full bg-white/20 hover:bg-white/30 transition-colors text-white"
          >
            <ChevronLeft size={18} />
          </button>
          <span className="text-white font-semibold text-base tracking-wide">{weekMonth}</span>
          <button
            onClick={() => setWeekStart(prev => addDays(prev, 7))}
            className="w-8 h-8 flex items-center justify-center rounded-full bg-white/20 hover:bg-white/30 transition-colors text-white"
          >
            <ChevronRight size={18} />
          </button>
        </div>

        <div className="grid grid-cols-7 gap-1">
          {datesInWeek.map((date, i) => {
            const isSelected = isSameDay(date, selectedDate);
            const dateKey = formatDateKey(date);
            const hasClass = daysWithClasses.has(dateKey);
            return (
              <button
                key={i}
                onClick={() => setSelectedDate(date)}
                className="flex flex-col items-center py-1.5 rounded-xl transition-colors"
                style={{ background: isSelected ? "rgba(255,255,255,0.95)" : "transparent" }}
              >
                <span className="text-xs font-medium mb-1" style={{ color: isSelected ? "#7c6fd4" : "rgba(255,255,255,0.8)" }}>
                  {WEEKDAY_SHORT[date.getDay()]}
                </span>
                <span className="text-sm font-bold leading-none" style={{ color: isSelected ? "#7c6fd4" : "white" }}>
                  {date.getDate()}
                </span>
                <span
                  className="mt-1.5 w-1.5 h-1.5 rounded-full"
                  style={{ background: hasClass ? (isSelected ? "#7c6fd4" : "#ff6b6b") : "transparent" }}
                />
              </button>
            );
          })}
        </div>

        <div className="flex justify-center mt-3">
          <ChevronRight size={16} className="text-white/60 rotate-90" />
        </div>
      </div>

      {/* Date label */}
      <div className="flex items-center gap-2 px-4 py-3">
        <Calendar size={15} className="text-indigo-500" />
        <span className="text-sm font-semibold text-slate-700">{formatFullDate(selectedDate)}</span>
      </div>

      {/* Class list */}
      <div className="flex-1 px-3">
        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => <Skeleton key={i} className="h-28 w-full rounded-2xl" />)}
          </div>
        ) : filteredSchedule.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-52 text-center px-4">
            <div className="w-16 h-16 rounded-full bg-indigo-50 flex items-center justify-center mb-3">
              <Calendar size={28} className="text-indigo-300" />
            </div>
            <p className="text-slate-600 font-semibold">Không có lịch học</p>
            <p className="text-slate-400 text-sm mt-1">Ngày này không có tiết học nào.</p>
          </div>
        ) : (
          <div className="space-y-3">
            <AnimatePresence mode="popLayout">
              {filteredSchedule.map((item, i) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.97 }}
                  transition={{ delay: i * 0.05, duration: 0.2 }}
                >
                  <button
                    className="w-full text-left bg-white rounded-2xl shadow-sm overflow-hidden flex active:scale-[0.98] transition-transform"
                    onClick={() => setDetail(item as ScheduleItem)}
                  >
                    {/* Left: time */}
                    <div
                      className="flex flex-col items-center justify-start pt-4 px-3 min-w-[64px]"
                      style={{ borderRight: "1px solid #f3f4f6" }}
                    >
                      <span className="text-base font-bold leading-none" style={{ color: item.color || "#7c6fd4" }}>
                        {item.startTime}
                      </span>
                      <span className="text-xs text-slate-400 mt-1 leading-none">{item.endTime}</span>
                    </div>

                    {/* Right: content */}
                    <div className="flex-1 px-3 py-3 pr-2">
                      <div className="flex items-start justify-between">
                        <p className="text-base font-bold text-slate-800 leading-tight">{item.subject}</p>
                        <ChevronRight size={18} className="text-slate-300 mt-0.5 flex-shrink-0" />
                      </div>
                      <div className="mt-1.5 space-y-1">
                        <div className="flex items-center gap-1.5 text-xs text-slate-500">
                          <MapPin size={12} className="text-slate-400" />
                          <span>{item.room}</span>
                        </div>
                        <div className="flex items-center gap-1.5 text-xs text-slate-500">
                          <User size={12} className="text-slate-400" />
                          <span>{item.teacher}</span>
                        </div>
                      </div>
                      <div className="flex gap-2 mt-2.5">
                        <span className="text-xs px-2.5 py-1 rounded-full border border-slate-200 text-slate-500 font-medium">
                          Chưa điểm danh
                        </span>
                        <span className="text-xs px-2.5 py-1 rounded-full border border-slate-200 text-slate-500 font-medium">
                          Offline
                        </span>
                      </div>
                    </div>
                  </button>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>

      {/* Detail slide-in panel */}
      <AnimatePresence>
        {detail && <DetailPanel item={detail} onBack={() => setDetail(null)} />}
      </AnimatePresence>
    </div>
  );
}
