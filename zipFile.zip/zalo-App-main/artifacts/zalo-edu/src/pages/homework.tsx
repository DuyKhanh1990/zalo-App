import { useState, useMemo, useEffect } from "react";
import { createPortal } from "react-dom";
import {
  useListHomework,
  useSubmitHomework,
  getListHomeworkQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import {
  ChevronLeft, ChevronRight, ChevronDown, ChevronUp,
  Send, Paperclip, Camera, Image, X, BookOpen,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

type HW = {
  id: number;
  type: string;
  title: string;
  subject: string;
  className: string;
  dueDate: string;
  startTime: string;
  endTime: string;
  status: string;
  description: string;
  teacher: string | null;
};

// ─── helpers ────────────────────────────────────────────────────────────────

function parseDueDate(dateStr: string) {
  const [y, m, d] = dateStr.split("-").map(Number);
  return new Date(y, m - 1, d);
}

const DOW_SHORT = ["CN", "T2", "T3", "T4", "T5", "T6", "T7"];

function formatGroupLabel(dateStr: string): string {
  const d = parseDueDate(dateStr);
  const dow = DOW_SHORT[d.getDay()];
  return `${dow}, ${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}/${d.getFullYear()}`;
}

function formatMonthYear(month: number, year: number) {
  return `Tháng ${month}, ${year}`;
}

function groupByDate(items: HW[]): [string, HW[]][] {
  const map = new Map<string, HW[]>();
  for (const item of items) {
    if (!map.has(item.dueDate)) map.set(item.dueDate, []);
    map.get(item.dueDate)!.push(item);
  }
  return Array.from(map.entries()).sort(([a], [b]) => a.localeCompare(b));
}

// ─── Badges ──────────────────────────────────────────────────────────────────

function TypeBadge({ type }: { type: string }) {
  const isBtvn = type === "btvn";
  return (
    <span
      className="text-[11px] font-bold px-1.5 py-0.5 rounded"
      style={{
        background: isBtvn ? "#ede9fe" : "#fce7f3",
        color: isBtvn ? "#7c3aed" : "#be185d",
      }}
    >
      {isBtvn ? "BTVN" : "Bài kiểm tra"}
    </span>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; bg: string; color: string }> = {
    pending:   { label: "Chưa nộp", bg: "#fff7ed", color: "#ea580c" },
    submitted: { label: "Đã nộp",   bg: "#f0fdf4", color: "#16a34a" },
    graded:    { label: "Đã chấm",  bg: "#eff6ff", color: "#2563eb" },
  };
  const s = map[status] ?? map.pending;
  return (
    <span
      className="text-xs font-semibold px-2.5 py-1 rounded-full"
      style={{ background: s.bg, color: s.color }}
    >
      {s.label}
    </span>
  );
}

// ─── Submit bottom sheet ─────────────────────────────────────────────────────

function SubmitSheet({ item, onClose }: { item: HW; onClose: () => void }) {
  const [text, setText] = useState("");
  const [done, setDone] = useState(false);
  const [portalRoot, setPortalRoot] = useState<HTMLElement | null>(null);
  const queryClient = useQueryClient();
  const mutation = useSubmitHomework();

  useEffect(() => {
    setPortalRoot(document.getElementById("sheet-root"));
  }, []);

  function handleSubmit() {
    mutation.mutate(
      { id: item.id },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListHomeworkQueryKey() });
          setDone(true);
          setTimeout(onClose, 1200);
        },
      }
    );
  }

  const content = (
    <div className="pointer-events-auto absolute inset-0 flex flex-col justify-end">
      {/* Backdrop */}
      <div
        className="absolute inset-0"
        style={{ background: "rgba(0,0,0,0.45)" }}
        onClick={onClose}
      />

      {/* Sheet panel */}
      <motion.div
        className="relative bg-white rounded-t-3xl flex flex-col overflow-hidden"
        style={{ maxHeight: "90%" }}
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        exit={{ y: "100%" }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
      >
        {/* Drag handle */}
        <div className="flex justify-center pt-3 pb-1 flex-shrink-0">
          <div className="w-10 h-1 rounded-full bg-slate-200" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-slate-100 flex-shrink-0">
          <div>
            <p className="font-bold text-slate-800 text-base">Nộp bài</p>
            <p className="text-xs text-slate-400 mt-0.5 line-clamp-1">{item.title}</p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-slate-100 transition-colors"
          >
            <X size={18} className="text-slate-500" />
          </button>
        </div>

        {/* Scrollable body */}
        <div className="flex-1 overflow-y-auto">
          {/* Teacher content */}
          <div className="px-5 py-4 border-b border-slate-100">
            <div className="flex items-center gap-1.5 mb-2">
              <BookOpen size={13} style={{ color: "#7c3aed" }} />
              <span className="text-xs font-bold tracking-wider uppercase" style={{ color: "#7c3aed" }}>
                Nội dung giáo viên
              </span>
            </div>
            <p className="text-sm text-slate-700 leading-relaxed">{item.description}</p>
          </div>

          {/* Student answer */}
          <div className="px-5 pt-4 pb-3">
            {/* Sub-tabs */}
            <div className="flex gap-4 mb-3 border-b border-slate-100 pb-2">
              {[
                { icon: <BookOpen size={13} />, label: "Bài làm của bạn", active: true },
                { icon: <Camera size={13} />, label: "Chụp ảnh", active: false },
                { icon: <Image size={13} />, label: "Thư viện", active: false },
              ].map((tab, i) => (
                <button
                  key={i}
                  className="flex items-center gap-1 text-xs font-semibold pb-1 transition-colors"
                  style={{
                    color: tab.active ? "#7c3aed" : "#94a3b8",
                    borderBottom: tab.active ? "2px solid #7c3aed" : "2px solid transparent",
                  }}
                >
                  {tab.icon}
                  {tab.label}
                </button>
              ))}
            </div>

            <textarea
              className="w-full text-sm text-slate-700 placeholder-slate-300 resize-none outline-none bg-transparent"
              rows={5}
              placeholder="Nhập nội dung bài làm..."
              value={text}
              onChange={e => setText(e.target.value)}
            />
          </div>

          {/* Attach hint */}
          <div className="px-5 pb-4 flex items-center gap-2 text-xs text-slate-400">
            <Paperclip size={13} />
            <span>Đính kèm file (tối đa 10MB)</span>
          </div>
        </div>

        {/* Submit button — always visible at bottom */}
        <div className="px-5 py-4 border-t border-slate-100 flex-shrink-0">
          <button
            onClick={handleSubmit}
            disabled={mutation.isPending || done}
            className="w-full h-12 rounded-2xl flex items-center justify-center gap-2 text-white font-semibold text-sm transition-all active:scale-[0.98] disabled:opacity-80"
            style={{
              background: done ? "#16a34a" : "linear-gradient(90deg, #7c3aed, #a855f7)",
            }}
          >
            <Send size={15} />
            {done ? "Đã nộp thành công!" : mutation.isPending ? "Đang nộp..." : "Nộp bài"}
          </button>
        </div>
      </motion.div>
    </div>
  );

  if (!portalRoot) return null;
  return createPortal(content, portalRoot);
}

// ─── Card ────────────────────────────────────────────────────────────────────

function HomeworkCard({ item, onSubmit }: { item: HW; onSubmit: (item: HW) => void }) {
  const isBtvn = item.type === "btvn";
  const canSubmit = item.status !== "graded" && isBtvn;
  const isSubmitted = item.status === "submitted";
  const [expanded, setExpanded] = useState(item.status === "pending" && isBtvn);

  const d = parseDueDate(item.dueDate);
  const meta = [
    item.className,
    `${DOW_SHORT[d.getDay()]}, ${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}`,
    `${item.startTime}–${item.endTime}`,
  ]
    .filter(Boolean)
    .join(" · ");

  return (
    <div
      className="bg-white rounded-2xl overflow-hidden shadow-sm"
      style={{ borderLeft: `4px solid ${isBtvn ? "#7c3aed" : "#ec4899"}` }}
    >
      <button
        className="w-full text-left px-4 pt-3.5 pb-3 flex items-start justify-between gap-2"
        onClick={() => isBtvn && setExpanded(e => !e)}
      >
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 flex-wrap mb-1.5">
            <TypeBadge type={item.type} />
            <span className="text-xs text-slate-400">{meta}</span>
          </div>
          <p className="text-sm font-bold text-slate-800 leading-snug">{item.title}</p>
          <div className="mt-2">
            <StatusBadge status={item.status} />
          </div>
        </div>
        {isBtvn && (
          <div className="mt-0.5 flex-shrink-0 text-slate-400">
            {expanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
          </div>
        )}
      </button>

      <AnimatePresence initial={false}>
        {expanded && canSubmit && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            style={{ overflow: "hidden" }}
          >
            <div className="px-4 pb-4 pt-1 border-t border-slate-50">
              <button
                onClick={e => { e.stopPropagation(); onSubmit(item); }}
                className="w-full h-10 rounded-xl flex items-center justify-center gap-2 text-sm font-semibold transition-all active:scale-[0.98]"
                style={
                  isSubmitted
                    ? { background: "#f8fafc", color: "#64748b", border: "1px solid #e2e8f0" }
                    : { background: "linear-gradient(90deg, #7c3aed, #a855f7)", color: "white" }
                }
              >
                <Send size={13} />
                {isSubmitted ? "Nộp lại" : "Nộp bài"}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── Filter chips ─────────────────────────────────────────────────────────────

const FILTERS = [
  { id: "all",       label: "Tất cả" },
  { id: "btvn",      label: "BTVN" },
  { id: "kiem_tra",  label: "Kiểm tra" },
  { id: "pending",   label: "Chưa nộp" },
  { id: "submitted", label: "Đã nộp" },
];

// ─── Main page ────────────────────────────────────────────────────────────────

export default function Homework() {
  const today = new Date();
  const [month, setMonth] = useState(today.getMonth() + 1);
  const [year, setYear]   = useState(today.getFullYear());
  const [filter, setFilter] = useState("all");
  const [submitItem, setSubmitItem] = useState<HW | null>(null);

  const { data: allItems, isLoading } = useListHomework();

  const items = useMemo<HW[]>(() => {
    if (!allItems) return [];
    let list = allItems as HW[];
    list = list.filter(item => {
      const d = parseDueDate(item.dueDate);
      return d.getMonth() + 1 === month && d.getFullYear() === year;
    });
    if (filter === "btvn")           list = list.filter(i => i.type === "btvn");
    else if (filter === "kiem_tra")  list = list.filter(i => i.type === "kiem_tra");
    else if (filter === "pending")   list = list.filter(i => i.status === "pending");
    else if (filter === "submitted") list = list.filter(i => i.status === "submitted");
    return list;
  }, [allItems, month, year, filter]);

  const stats = useMemo(() => {
    if (!allItems) return { btvnDone: 0, btvnTotal: 0, kiemTra: 0 };
    const inMonth = (allItems as HW[]).filter(i => {
      const d = parseDueDate(i.dueDate);
      return d.getMonth() + 1 === month && d.getFullYear() === year;
    });
    const btvns = inMonth.filter(i => i.type === "btvn");
    return {
      btvnDone:  btvns.filter(i => i.status === "submitted" || i.status === "graded").length,
      btvnTotal: btvns.length,
      kiemTra:   inMonth.filter(i => i.type === "kiem_tra").length,
    };
  }, [allItems, month, year]);

  const groups = useMemo(() => groupByDate(items), [items]);

  function prevMonth() {
    if (month === 1) { setMonth(12); setYear(y => y - 1); }
    else setMonth(m => m - 1);
  }
  function nextMonth() {
    if (month === 12) { setMonth(1); setYear(y => y + 1); }
    else setMonth(m => m + 1);
  }

  return (
    <div className="flex flex-col min-h-full pb-20" style={{ background: "#f5f5fb" }}>
      {/* Header */}
      <div
        className="px-4 pt-10 pb-4"
        style={{ background: "linear-gradient(160deg, #c3b8f5 0%, #a89de8 40%, #8f84d8 100%)" }}
      >
        <div className="flex items-center justify-between mb-3">
          <button
            onClick={prevMonth}
            className="w-8 h-8 flex items-center justify-center rounded-full bg-white/20 hover:bg-white/30 transition-colors text-white"
          >
            <ChevronLeft size={18} />
          </button>
          <span className="text-white font-semibold text-base">{formatMonthYear(month, year)}</span>
          <button
            onClick={nextMonth}
            className="w-8 h-8 flex items-center justify-center rounded-full bg-white/20 hover:bg-white/30 transition-colors text-white"
          >
            <ChevronRight size={18} />
          </button>
        </div>
        <div className="flex items-center justify-between px-1">
          <span className="text-white/90 text-sm font-medium">
            {stats.btvnDone}/{stats.btvnTotal} BTVN đã nộp
          </span>
          <span className="text-white/90 text-sm font-medium">
            {stats.kiemTra} bài kiểm tra
          </span>
        </div>
      </div>

      {/* Filter chips */}
      <div className="px-4 py-3">
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-0.5">
          {FILTERS.map(f => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className="flex-shrink-0 px-4 py-1.5 rounded-full text-sm font-semibold transition-all"
              style={
                filter === f.id
                  ? { background: "#7c3aed", color: "white" }
                  : { background: "white", color: "#64748b", border: "1px solid #e2e8f0" }
              }
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* List */}
      <div className="flex-1 px-4">
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map(i => <Skeleton key={i} className="h-28 w-full rounded-2xl" />)}
          </div>
        ) : groups.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-52 text-center px-4">
            <div className="w-16 h-16 rounded-full bg-purple-50 flex items-center justify-center mb-3">
              <BookOpen size={28} className="text-purple-200" />
            </div>
            <p className="text-slate-600 font-semibold">Không có bài tập</p>
            <p className="text-slate-400 text-sm mt-1">Tháng này không có BTVN hay bài kiểm tra.</p>
          </div>
        ) : (
          <div className="space-y-5">
            {groups.map(([dateKey, groupItems]) => (
              <div key={dateKey}>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-sm font-bold text-slate-600">{formatGroupLabel(dateKey)}</span>
                  <span className="text-xs text-slate-400 font-medium">{groupItems.length} bài</span>
                </div>
                <div className="space-y-2.5">
                  <AnimatePresence mode="popLayout">
                    {groupItems.map((item, i) => (
                      <motion.div
                        key={item.id}
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.97 }}
                        transition={{ delay: i * 0.04, duration: 0.18 }}
                      >
                        <HomeworkCard item={item} onSubmit={setSubmitItem} />
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Submit sheet — rendered via portal into #sheet-root in the layout */}
      <AnimatePresence>
        {submitItem && (
          <SubmitSheet item={submitItem} onClose={() => setSubmitItem(null)} />
        )}
      </AnimatePresence>
    </div>
  );
}
