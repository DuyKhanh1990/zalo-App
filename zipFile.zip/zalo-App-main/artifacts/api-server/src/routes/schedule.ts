import { Router, type IRouter } from "express";
import { db, scheduleTable } from "@workspace/db";
import { ListScheduleResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/schedule", async (req, res): Promise<void> => {
  const rows = await db.select().from(scheduleTable).orderBy(scheduleTable.date, scheduleTable.startTime);
  res.json(ListScheduleResponse.parse(rows.map(r => ({
    id: r.id,
    subject: r.subject,
    teacher: r.teacher,
    room: r.room,
    dayOfWeek: r.dayOfWeek,
    startTime: r.startTime,
    endTime: r.endTime,
    date: r.date,
    color: r.color,
  }))));
});

export default router;
