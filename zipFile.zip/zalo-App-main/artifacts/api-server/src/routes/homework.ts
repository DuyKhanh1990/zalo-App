import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, homeworkTable } from "@workspace/db";
import {
  ListHomeworkResponse,
  CreateHomeworkBody,
  SubmitHomeworkParams,
  SubmitHomeworkResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

function toDto(r: typeof homeworkTable.$inferSelect) {
  return {
    id: r.id,
    type: r.type,
    title: r.title,
    subject: r.subject,
    className: r.className,
    dueDate: r.dueDate,
    startTime: r.startTime,
    endTime: r.endTime,
    status: r.status,
    description: r.description,
    teacher: r.teacher,
  };
}

router.get("/homework", async (req, res): Promise<void> => {
  const { status, type } = req.query as { status?: string; type?: string };
  let rows = await db.select().from(homeworkTable).orderBy(homeworkTable.dueDate);
  if (status && status !== "all") rows = rows.filter(r => r.status === status);
  if (type && type !== "all") rows = rows.filter(r => r.type === type);
  res.json(ListHomeworkResponse.parse(rows.map(toDto)));
});

router.post("/homework", async (req, res): Promise<void> => {
  const parsed = CreateHomeworkBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [row] = await db.insert(homeworkTable).values({
    type: parsed.data.type ?? "btvn",
    title: parsed.data.title,
    subject: parsed.data.subject,
    className: parsed.data.className ?? "",
    dueDate: parsed.data.dueDate,
    startTime: parsed.data.startTime ?? "",
    endTime: parsed.data.endTime ?? "",
    description: parsed.data.description,
    teacher: parsed.data.teacher,
    status: "pending",
  }).returning();
  res.status(201).json(SubmitHomeworkResponse.parse(toDto(row)));
});

router.patch("/homework/:id/submit", async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = SubmitHomeworkParams.safeParse({ id: parseInt(rawId, 10) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db
    .update(homeworkTable)
    .set({ status: "submitted" })
    .where(eq(homeworkTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Homework not found" });
    return;
  }
  res.json(SubmitHomeworkResponse.parse(toDto(row)));
});

export default router;
