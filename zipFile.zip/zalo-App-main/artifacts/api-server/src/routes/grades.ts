import { Router, type IRouter } from "express";
import { db, gradesTable } from "@workspace/db";
import { ListGradesResponse, GetGradeSummaryResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/grades", async (req, res): Promise<void> => {
  const { subject, semester } = req.query as { subject?: string; semester?: string };
  let rows = await db.select().from(gradesTable).orderBy(gradesTable.subject);
  if (subject) rows = rows.filter(r => r.subject === subject);
  if (semester) rows = rows.filter(r => r.semester === semester);
  res.json(ListGradesResponse.parse(rows.map(r => ({
    id: r.id,
    subject: r.subject,
    semester: r.semester,
    midterm: r.midterm,
    final: r.final,
    average: r.average,
    letterGrade: r.letterGrade,
    teacher: r.teacher,
  }))));
});

router.get("/grades/summary", async (_req, res): Promise<void> => {
  const rows = await db.select().from(gradesTable);
  const totalSubjects = rows.length;
  const passed = rows.filter(r => r.average >= 5).length;
  const failed = rows.filter(r => r.average < 5).length;
  const excellent = rows.filter(r => r.average >= 8.5).length;
  const gpa = totalSubjects > 0
    ? Math.round((rows.reduce((s, r) => s + r.average, 0) / totalSubjects) * 10) / 10
    : 0;
  res.json(GetGradeSummaryResponse.parse({ gpa, totalSubjects, passed, failed, excellent }));
});

export default router;
