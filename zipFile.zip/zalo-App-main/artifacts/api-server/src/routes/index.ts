import { Router, type IRouter } from "express";
import healthRouter from "./health";
import scheduleRouter from "./schedule";
import homeworkRouter from "./homework";
import gradesRouter from "./grades";
import invoicesRouter from "./invoices";

const router: IRouter = Router();

router.use(healthRouter);
router.use(scheduleRouter);
router.use(homeworkRouter);
router.use(gradesRouter);
router.use(invoicesRouter);

export default router;
