import { Router, type IRouter } from "express";
import { db, invoicesTable } from "@workspace/db";
import { ListInvoicesResponse, GetInvoiceSummaryResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/invoices", async (req, res): Promise<void> => {
  const { status } = req.query as { status?: string };
  let rows = await db.select().from(invoicesTable).orderBy(invoicesTable.dueDate);
  if (status && status !== "all") {
    rows = rows.filter(r => r.status === status);
  }
  res.json(ListInvoicesResponse.parse(rows.map(r => ({
    id: r.id,
    title: r.title,
    amount: r.amount,
    dueDate: r.dueDate,
    status: r.status,
    semester: r.semester,
    category: r.category,
    paidAt: r.paidAt,
  }))));
});

router.get("/invoices/summary", async (_req, res): Promise<void> => {
  const rows = await db.select().from(invoicesTable);
  const totalDue = rows.filter(r => r.status !== "paid").reduce((s, r) => s + r.amount, 0);
  const totalPaid = rows.filter(r => r.status === "paid").reduce((s, r) => s + r.amount, 0);
  const overdue = rows.filter(r => r.status === "overdue").reduce((s, r) => s + r.amount, 0);
  const upcoming = rows.filter(r => r.status === "unpaid").length;
  res.json(GetInvoiceSummaryResponse.parse({ totalDue, totalPaid, overdue, upcoming }));
});

export default router;
